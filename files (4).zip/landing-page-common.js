/* MySellerDesk auth + routing helpers — FIXED VERSION */
(function(){
  const cfg = window.SELLERDESK_CONFIG || {};
  function trimSlash(v){ return (v || '').replace(/\/$/, ''); }

  window.getSiteUrl = function(){
    return trimSlash(cfg.SITE_URL || window.location.origin);
  };

  window.getAppUrl = function(){
    return trimSlash(cfg.APP_URL || window.location.origin);
  };

  window.getDashboardUrl = function(params){
    const base = getAppUrl() + (cfg.DASHBOARD_PATH || '/index.html');
    if(!params) return base;
    const url = new URL(base, window.location.href);
    Object.keys(params).forEach(function(key){
      if(params[key] !== undefined && params[key] !== null && params[key] !== ''){
        url.searchParams.set(key, params[key]);
      }
    });
    return url.toString();
  };

  window.redirectToDashboard = function(payload){
    const target = getDashboardUrl(payload || {});
    window.location.href = target;
  };
})();

/* ══════════════════════════════════════════════
   FIX 2: Supabase client with COOKIE storage
   so session works across mysellerdesk.in
   AND app.mysellerdesk.in subdomains
   ══════════════════════════════════════════════ */
function getSupabaseClient(){
  const cfg = window.SELLERDESK_CONFIG || {};
  if(!cfg.SUPABASE_URL || !cfg.SUPABASE_ANON_KEY ||
     cfg.SUPABASE_ANON_KEY === 'PASTE_YOUR_REAL_SUPABASE_ANON_KEY_HERE'){
    console.error('MySellerDesk: SUPABASE_URL or SUPABASE_ANON_KEY missing / placeholder in config.js');
    return null;
  }

  // Use cookies with domain=.mysellerdesk.in so BOTH subdomains share the session
  return window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY, {
    auth: {
      storageKey: 'sd_supabase_auth',
      // ✅ FIX: Use cookie storage, not localStorage, for cross-subdomain auth
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: true,
      flowType: 'pkce',
      // Cookie options — dot prefix makes it work on all *.mysellerdesk.in
      cookieOptions: {
        domain: '.mysellerdesk.in',
        sameSite: 'Lax',
        secure: true,
        maxAge: 60 * 60 * 24 * 7  // 7 days
      }
    }
  });
}

/* ══════════════════════════════════════════════
   FIX 3: Idle logout — 10 min inactivity
   Clears ALL sd_ localStorage keys on logout
   ══════════════════════════════════════════════ */
(function setupIdleLogout(){
  const cfg = window.SELLERDESK_CONFIG || {};
  const TIMEOUT = cfg.IDLE_TIMEOUT_MS || 600000; // 10 min default
  let idleTimer = null;

  function clearSdStorage(){
    const keysToRemove = [];
    for(let i = 0; i < localStorage.length; i++){
      const k = localStorage.key(i);
      if(k && k.startsWith('sd_')) keysToRemove.push(k);
    }
    keysToRemove.forEach(k => localStorage.removeItem(k));

    // Also clear supabase auth key
    localStorage.removeItem('sd_supabase_auth');
    sessionStorage.clear();
  }

  async function doIdleLogout(){
    clearSdStorage();
    const client = getSupabaseClient();
    if(client){
      await client.auth.signOut();
    }
    // Redirect to landing page
    const cfg2 = window.SELLERDESK_CONFIG || {};
    window.location.href = (cfg2.SITE_URL || window.location.origin) + '/?timeout=1';
  }

  function resetTimer(){
    clearTimeout(idleTimer);
    idleTimer = setTimeout(doIdleLogout, TIMEOUT);
  }

  // Only activate idle logout if user is logged in
  if(localStorage.getItem('sd_logged_in') === '1'){
    ['mousemove','keydown','click','touchstart','scroll'].forEach(function(evt){
      document.addEventListener(evt, resetTimer, { passive: true });
    });
    resetTimer(); // start the timer
  }

  // Expose for dashboard to call after login
  window.startIdleLogoutTimer = function(){
    ['mousemove','keydown','click','touchstart','scroll'].forEach(function(evt){
      document.addEventListener(evt, resetTimer, { passive: true });
    });
    resetTimer();
  };

  window.clearSdStorage = clearSdStorage;
})();

/* ══════════════════════════════════════════════
   MODAL helpers
   ══════════════════════════════════════════════ */
function openModal(tab){
  const modal = document.getElementById('authModal');
  if(!modal) return;
  modal.classList.add('show');
  switchTab(tab || 'login');
  document.body.style.overflow = 'hidden';
}

function closeAuthModal(){
  const modal = document.getElementById('authModal');
  if(!modal) return;
  modal.classList.remove('show');
  document.body.style.overflow = '';
  const err = document.getElementById('login-error');
  if(err) err.style.display = 'none';
}

function closeModal(id){
  if(id){
    const el = document.getElementById(id);
    if(el) el.classList.remove('show');
  } else {
    closeAuthModal();
  }
}

function switchTab(tab){
  document.querySelectorAll('.modal-tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.modal-panel').forEach(p => p.classList.remove('active'));
  const tabEl = document.getElementById('tab-' + tab);
  const panelEl = document.getElementById('panel-' + tab);
  if(tabEl) tabEl.classList.add('active');
  if(panelEl) panelEl.classList.add('active');
  const err = document.getElementById('login-error');
  if(err) err.style.display = 'none';
}

/* ══════════════════════════════════════════════
   LOGIN
   ══════════════════════════════════════════════ */
async function handleLogin(){
  const emailEl = document.getElementById('login-email');
  const passEl  = document.getElementById('login-pass');
  const errDiv  = document.getElementById('login-error');

  if(!emailEl || !passEl || !errDiv) return;

  const email = emailEl.value.trim();
  const pass  = passEl.value;

  if(!email || !pass){
    errDiv.textContent = 'Enter email & password';
    errDiv.style.display = 'block';
    return;
  }

  const client = getSupabaseClient();
  if(!client){
    errDiv.textContent = 'Configuration error. Please contact support.';
    errDiv.style.display = 'block';
    return;
  }

  const btn = document.querySelector('#panel-login .btn-modal-primary');
  if(btn){ btn.textContent = 'Logging in…'; btn.disabled = true; }

  const { data, error } = await client.auth.signInWithPassword({ email, password: pass });

  if(btn){ btn.textContent = 'Log in to MySellerDesk'; btn.disabled = false; }

  if(error){
    errDiv.textContent = error.message;
    errDiv.style.display = 'block';
    return;
  }

  const user = data.user;

  /* ✅ Set localStorage for dashboard bridge */
  localStorage.setItem('sd_logged_in', '1');
  localStorage.setItem('sd_user_email', user.email || email);
  localStorage.setItem('sd_last_active', Date.now().toString());

  /* Fetch profile */
  const { data: profile } = await client
    .from('profiles')
    .select('shop_name, plan')
    .eq('id', user.id)
    .single();

  if(profile && profile.shop_name){
    localStorage.setItem('sd_shop_name', profile.shop_name);
  }
  if(profile && profile.plan){
    localStorage.setItem('sd_plan', profile.plan);
  }

  // Start idle timer before redirecting
  if(window.startIdleLogoutTimer) window.startIdleLogoutTimer();

  window.location.href = getDashboardUrl({ auth:'1', email: user.email });
}

/* ══════════════════════════════════════════════
   SIGNUP
   ══════════════════════════════════════════════ */
async function handleSignup(){
  const shopEl  = document.getElementById('signup-shop');
  const emailEl = document.getElementById('signup-email');
  const passEl  = document.getElementById('signup-pass');

  if(!shopEl || !emailEl || !passEl) return;

  const shop  = shopEl.value.trim();
  const email = emailEl.value.trim();
  const pass  = passEl.value;

  if(!shop || !email || !pass){
    alert('Please fill all fields');
    return;
  }
  if(pass.length < 8){
    alert('Password must be at least 8 characters');
    return;
  }

  const client = getSupabaseClient();
  if(!client){
    alert('Configuration error. Please contact support.');
    return;
  }

  const btn = document.querySelector('#panel-signup .btn-modal-primary');
  if(btn){ btn.textContent = 'Creating account…'; btn.disabled = true; }

  const { data, error } = await client.auth.signUp({ email, password: pass });

  if(btn){ btn.textContent = 'Create Free Account →'; btn.disabled = false; }

  if(error){
    alert(error.message);
    return;
  }

  /* Email confirmation required (session is null) */
  if(!data.session){
    closeAuthModal();
    alert('✅ Account created! Please check your email to confirm your address, then log in.');
    sessionStorage.setItem('sd_pending_shop', shop);
    return;
  }

  const user = data.user;

  /* Insert profile */
  const { error: profileError } = await client.from('profiles').insert({
    id: user.id,
    shop_name: shop,
    email: email
  });

  if(profileError && profileError.code !== '23505'){
    console.warn('Profile insert error:', profileError.message);
  }

  localStorage.setItem('sd_logged_in', '1');
  localStorage.setItem('sd_user_email', email);
  localStorage.setItem('sd_shop_name', shop);
  localStorage.setItem('sd_last_active', Date.now().toString());

  if(window.startIdleLogoutTimer) window.startIdleLogoutTimer();

  window.location.href = getDashboardUrl({ auth:'1', email, shop });
}
